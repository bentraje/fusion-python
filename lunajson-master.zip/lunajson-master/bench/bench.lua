local util = require 'util'

util.load('decoder/bench.lua')
util.load('encoder/bench.lua')
