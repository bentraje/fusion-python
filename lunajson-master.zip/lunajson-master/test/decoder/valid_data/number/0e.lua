return 0.0
