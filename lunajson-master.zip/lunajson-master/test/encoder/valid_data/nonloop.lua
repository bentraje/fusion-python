local a = {1, 2, 3}
local b = {a, a}
local c = {x = b, y = b}
return c
